import './App.css';
import FormWizard from './Page/Form/FormWizard';


function App() {
  return (
   <>
   <FormWizard/>
   </>
  );
}

export default App;
